package TeriseGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;

public class Rank extends JPanel{
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(300, 440);
		
		frame.add(rank());
		//frame.setResizable(false);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
	
	public static JPanel rank() {
		JPanel panel = new JPanel();
		panel.setLayout(null);
		
		JButton button1 = new JButton("��");
		JButton button2 = new JButton("�е�");
		JButton button3 = new JButton("����");
		JButton button4 = new JButton("��̬");
		JButton button5 = new JButton("����");
		
		ActionListener l = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("111");
				panel.repaint();
			}
		};
		
		button1.addActionListener(l);
		button2.addActionListener(l);
		button3.addActionListener(l);
		button4.addActionListener(l);
		button5.addActionListener(l);
		
		button1.setBounds(0, 0, 58, 30);
		button2.setBounds(58, 0, 58, 30);
		button3.setBounds(116, 0, 58, 30);
		button4.setBounds(174, 0, 58, 30);
		button5.setBounds(232, 0, 58, 30);
		
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
		panel.add(button4);
		panel.add(button5);
		
		JLabel[] scores = new JLabel[33];
		scores[0]=new JLabel();
		scores[1]=new JLabel();
		scores[2]=new JLabel();
		scores[0].setText("����");
		scores[1].setText("�û���");
		scores[2].setText("����");
		
		for(Integer i=3,j=0;i<33;i=i+3) {
			j++;
			scores[i]=new JLabel();
			scores[i].setText(j.toString());
		}

		for(Integer i=4;i<33;i=i+3) {
			scores[i]=new JLabel();
			scores[i].setText(i.toString());
		}
		
		for(Integer i=5;i<33;i=i+3) {
			scores[i]=new JLabel();
			scores[i].setText(i.toString());
		}
		
		for(int i=0;i<33;i++) {
			scores[i].setBounds(i%3*100+30, i/3*30+40, 70, 20);
			panel.add(scores[i]);
		}
		
		return panel;
	}
}
