package TeriseGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;

public class MainTest {

	public static void main(String[] args) {

		JFrame frame = new JFrame();
		
		Tetris panel = new Tetris();
		frame.setSize(panel.width*25, panel.height*15);
		frame.add(panel);

		ActionListener itemListener1 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JMenuItem menuItem = (JMenuItem) e.getSource();
				String menuid = menuItem.getText();
				if (menuid == "����Ϸ") {
					panel.gamestate = true;
					panel.gameover = false;
					panel.run();
				}

				if (menuid == "��ʼ") {
					if (panel.gameover == true) {
						panel.gameover = false;
						panel.run();
					}
					panel.gamestate = true;
				}

				if (menuid == "��ͣ") {
					panel.gamestate = false;
				}

				if (menuid == "�˳�") {
					System.exit(0);
				}

			}
		};

		JMenuBar menubar = new JMenuBar();
		frame.setJMenuBar(menubar);

		JMenu menu1 = new JMenu("��Ϸ");
		menubar.add(menu1);
		JMenuItem item1 = new JMenuItem("����Ϸ");
		JMenuItem item2 = new JMenuItem("��ʼ");
		JMenuItem item3 = new JMenuItem("��ͣ");
		JMenuItem item4 = new JMenuItem("�˳�");
		item1.addActionListener(itemListener1);
		item2.addActionListener(itemListener1);
		item3.addActionListener(itemListener1);
		item4.addActionListener(itemListener1);
		menu1.add(item1);
		menu1.add(item2);
		menu1.add(item3);
		menu1.add(item4);

		JMenu menu2 = new JMenu("�Ѷ�");
		menubar.add(menu2);
		JRadioButtonMenuItem buttonMenuItem1 = new JRadioButtonMenuItem("��");
		JRadioButtonMenuItem buttonMenuItem2 = new JRadioButtonMenuItem("�е�");
		JRadioButtonMenuItem buttonMenuItem3 = new JRadioButtonMenuItem("����");
		JRadioButtonMenuItem buttonMenuItem4 = new JRadioButtonMenuItem("��̬");
		JRadioButtonMenuItem buttonMenuItem5 = new JRadioButtonMenuItem("����");

		ButtonGroup group = new ButtonGroup();
		group.add(buttonMenuItem1);
		group.add(buttonMenuItem2);
		group.add(buttonMenuItem3);
		group.add(buttonMenuItem4);
		group.add(buttonMenuItem5);
		menu2.add(buttonMenuItem1);
		menu2.add(buttonMenuItem2);
		menu2.add(buttonMenuItem3);
		menu2.add(buttonMenuItem4);
		menu2.add(buttonMenuItem5);
		buttonMenuItem1.setSelected(true);

		ActionListener itemlistener2 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == buttonMenuItem1) {
					panel.setTime(0, "��");
				}

				if (e.getSource() == buttonMenuItem2) {
					panel.setTime(1, "�е�");
				}

				if (e.getSource() == buttonMenuItem3) {
					panel.setTime(2, "����");
				}

				if (e.getSource() == buttonMenuItem4) {
					panel.setTime(3, "��̬");
				}

				if (e.getSource() == buttonMenuItem5) {
					panel.setTime(4, "����");
				}
			}
		};

		buttonMenuItem1.addActionListener(itemlistener2);
		buttonMenuItem2.addActionListener(itemlistener2);
		buttonMenuItem3.addActionListener(itemlistener2);
		buttonMenuItem4.addActionListener(itemlistener2);
		buttonMenuItem5.addActionListener(itemlistener2);
		
		JMenu menu3 = new JMenu("�û�");
		menubar.add(menu3);
		JMenuItem loaditem = new JMenuItem("��¼");
		JMenuItem regitem = new JMenuItem("ע��");
		JMenuItem rankitem = new JMenuItem("���а�");
		ActionListener itemlistener3 = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JMenuItem menuItem = (JMenuItem) e.getSource();
				String menuid = menuItem.getText();
				if(menuid=="��¼") {
					Login.main(args);
				}
				
				if(menuid=="ע��") {
					Register.main(args);
				}
				
				if(menuid=="���а�") {
					Rank.main(args);
				}
			}
		};
		loaditem.addActionListener(itemlistener3);
		regitem.addActionListener(itemlistener3);
		rankitem.addActionListener(itemlistener3);
		menu3.add(loaditem);
		menu3.add(regitem);
		menu3.add(rankitem);

		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}