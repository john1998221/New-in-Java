package TeriseGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login extends JPanel{

	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(300, 150);
		frame.add(login());
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
	
	public static JPanel login() {
		JPanel panel = new JPanel();
		panel.setLayout(null);
		JLabel jl=new JLabel("�û�����");
		jl.setBounds(10, 10, 200, 18);
		final JTextField name=new JTextField();
		name.setBounds(80, 10, 150, 18);
		
		JLabel jl2=new JLabel("���룺");
		jl2.setBounds(10, 50, 200, 18);
		final JPasswordField password=new JPasswordField();
		password.setBounds(80, 50, 150, 18);
		
		panel.add(jl);
		panel.add(name);
		panel.add(jl2);
		panel.add(password);
		
		JButton jb=new JButton("ȷ��");
		jb.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent arg0) {
				
				if(name.getText().trim().length()==0||new String(password.getPassword()).trim().length()==0){
					JOptionPane.showMessageDialog(null, "�û������벻����Ϊ��");
					return;
				}
				if(name.getText().trim().equals("lzp")&&new String(password.getPassword()).trim().equals("123456")){
					JOptionPane.showMessageDialog(null, "��¼�ɹ�");
				}
				else{
					JOptionPane.showMessageDialog(null, "�û������������");
					password.setText("");
				}
			}
		});
		jb.setBounds(80, 80, 60, 18);
		panel.add(jb);
		
		final JButton button = new JButton();
		button.setText("����");
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				name.setText("");
				password.setText("");
			}
		});
		button.setBounds(150, 80, 60, 18);
		panel.add(button);
		return panel;
	}
}