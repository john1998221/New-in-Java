package TeriseGame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Register extends JPanel{

	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(300,200);
		frame.add(regester());
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
	
	public static JPanel regester() {
		JPanel panel = new JPanel();
		panel.setLayout(null);
		JLabel jl=new JLabel("�û�����");
		jl.setBounds(10, 10, 200, 18);
		final JTextField name=new JTextField();
		name.setBounds(80, 10, 150, 18);
		
		JLabel jl2=new JLabel("���룺");
		jl2.setBounds(10, 50, 200, 18);
		final JPasswordField password1=new JPasswordField();
		password1.setBounds(80, 50, 150, 18);
		
		JLabel jl3=new JLabel("ȷ�����룺");
		jl3.setBounds(10, 90, 200, 18);
		final JPasswordField password2=new JPasswordField();
		password2.setBounds(80, 90, 150, 18);
		
		panel.add(jl);
		panel.add(name);
		panel.add(jl2);
		panel.add(password1);
		panel.add(jl3);
		panel.add(password2);
		
		JButton jb=new JButton("ȷ��");
		jb.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e) {
				
				if(name.getText().trim().length()==0||new String(password1.getPassword()).trim().length()==0){
					JOptionPane.showMessageDialog(null, "�û������벻����Ϊ��");
					return;
				}
				if(new String(password1.getPassword()).trim().equals(new String(password2.getPassword()).trim())){
					JOptionPane.showMessageDialog(null, "ע��ɹ�");
				}
				else{
					JOptionPane.showMessageDialog(null, "�������벻һ��");
					password1.setText("");
					password2.setText("");
				}
			}
		});
		jb.setBounds(80, 120, 60, 18);
		panel.add(jb);
		
		final JButton button = new JButton();
		button.setText("����");
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				name.setText("");
				password1.setText("");
				password2.setText("");
			}
		});
		button.setBounds(150, 120, 60, 18);
		panel.add(button);
		return panel;
	}
}