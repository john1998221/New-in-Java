package server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class Connect {
	public synchronized static Connection getConnectionByJNDI() {
        Connection con = null;
        try {
            Context initCtx = new InitialContext();
            Context envCtx = (Context) initCtx.lookup("java:comp/env");
		//����д�����ǲ���ģ�����������lookup�е��ַ����������õ�JNDI���ƣ�
		//����context�е�<resource name="xxx">����web.xml�е�<resource-env-ref-name>
            DataSource ds = (DataSource)envCtx.lookup("jdbc/MySql");
            con = ds.getConnection();
        } catch (NamingException e) {
            e.printStackTrace();
            System.out.println("���Ӵ���");

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("��ȡ����ʧ�ܣ�");

        }
        return con;
    }
    public static void closeResource(ResultSet rs, Statement stmt, Connection con){
        try {
            if(rs != null){
                rs.close();
            }
            if(stmt != null){
                stmt.close();
            }
            if(con != null){
                con.close();
            }
        }catch (SQLException e) {
            System.out.println("�ر���Դʧ�ܣ�");
// e.printStackTrace();
        }
    }
    public static void result(){
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = getConnectionByJNDI();
            ps = conn.prepareStatement("select * from user");
            rs = ps.executeQuery();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            closeResource(rs,ps,conn);
        }
    }
}
