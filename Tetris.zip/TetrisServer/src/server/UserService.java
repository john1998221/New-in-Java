package server;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@WebService
public class UserService {
	public boolean login(String json) {
		UserScore user = Json.unbox(json);
		Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Connect.getConnectionByJNDI();
            ps = conn.prepareStatement("select * from user where username=? and password=?");
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            rs = ps.executeQuery();
            if(rs.next()) {
            	return true;
            }
            else {
            	return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            Connect.closeResource(rs,ps,conn);
        }
		return false;
	}
	
	@SuppressWarnings("resource")
	public boolean regester(String json) {
		UserScore user = Json.unbox(json);
		Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Connect.getConnectionByJNDI();
            ps = conn.prepareStatement("select * from user where username=?");
            ps.setString(1, user.getUsername());
            rs = ps.executeQuery();
            if(rs.next()) {
            	return false;
            }
            else {
                ps = conn.prepareStatement("insert into user values(?,?)");
                ps.setString(1, user.getUsername());
                ps.setString(2, user.getPassword());
                int n = ps.executeUpdate();
                if(n==1) {
                	return true;
                }
                else {
                	return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            Connect.closeResource(rs,ps,conn);
        }
		return false;
	}
	
	public boolean setscore(String json) {
		UserScore user = Json.unbox(json);
		Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
        	conn = Connect.getConnectionByJNDI();
        	ps = conn.prepareStatement("insert into scores values(?,?,?) ON DUPLICATE KEY UPDATE score=case when score<? then ? else score end");
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getDegree());
            ps.setInt(3, user.getScore());
            ps.setInt(4, user.getScore());
            ps.setInt(5, user.getScore());
            int n = ps.executeUpdate();
            if(n==0) {
            	return false;
            }
            else {
            	return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            Connect.closeResource(rs,ps,conn);
        }
		return false;
	}
	
	public String getscore(String json) {
		UserScore user = Json.unbox(json);
		List<UserScore> stuList = new ArrayList<UserScore>();
		Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = Connect.getConnectionByJNDI();
            ps = conn.prepareStatement("select * from scores where degree=? order by score desc");
            ps.setString(1, user.getDegree());
            rs = ps.executeQuery();
            while(rs.next()){
                UserScore us=new UserScore();
                String username = rs.getString("username");
                String degree = rs.getString("degree");
                int score = rs.getInt("score");
                us.setUsername(username);
                us.setDegree(degree);
                us.setScore(score);
                stuList.add(us);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            Connect.closeResource(rs,ps,conn);
        }
        ObjectMapper mapper = new ObjectMapper();
		String json2 = null;
		try {
			json2 = mapper.writeValueAsString(stuList);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return json2;
	}
}
