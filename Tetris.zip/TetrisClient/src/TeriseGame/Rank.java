package TeriseGame;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JPanel;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ClientService.ClientService;
import ClientService.UserScore;


public class Rank extends JPanel{
	private static final long serialVersionUID = 1L;
	
	public static void rank(){
		CardLayout cardLayout = new CardLayout();
		JFrame frame = new JFrame();
		frame.setSize(300, 440);
		JPanel panel = new JPanel(cardLayout);
		JPanel panel1 = search("��");
		JPanel panel2 = search("�е�");
		JPanel panel3 = search("����");
		JPanel panel4 = search("��̬");
		JPanel panel5 = search("����");
		panel.add(panel1,"p1");
		panel.add(panel2,"p2");
		panel.add(panel3,"p3");
		panel.add(panel4,"p4");
		panel.add(panel5,"p5");
		
		JButton button1 = new JButton("��");
		JButton button2 = new JButton("�е�");
		JButton button3 = new JButton("����");
		JButton button4 = new JButton("��̬");
		JButton button5 = new JButton("����");
		
		ActionListener l = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if(source==button1) {
					cardLayout.show(panel, "p1");
					frame.repaint();
				}
				
				if(source==button2) {
					cardLayout.show(panel, "p2");
					frame.repaint();
				}
				
				if(source==button3) {
					cardLayout.show(panel, "p3");
					frame.repaint();
				}
				
				if(source==button4) {
					cardLayout.show(panel, "p4");
					frame.repaint();
				}
				
				if(source==button5) {
					cardLayout.show(panel, "p5");
					frame.repaint();
				}
			}
		};
		
		button1.addActionListener(l);
		button2.addActionListener(l);
		button3.addActionListener(l);
		button4.addActionListener(l);
		button5.addActionListener(l);
		
		button1.setBounds(0, 0, 60, 30);
		button2.setBounds(59, 0, 60, 30);
		button3.setBounds(118, 0, 60, 30);
		button4.setBounds(177, 0, 60, 30);
		button5.setBounds(236, 0, 60, 30);
		
		frame.add(button1,0);
		frame.add(button2,1);
		frame.add(button3,2);
		frame.add(button4,3);
		frame.add(button5,4);
		
		frame.add(panel);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
	
	public static JPanel search(String degree) {
		UserScore user = new UserScore();
		user.setDegree(degree);
		List<UserScore> rank = new ArrayList<UserScore>();
		JPanel panel = new JPanel();
		panel.setLayout(null);
		
		JLabel[] scores = new JLabel[33];
		scores[0]=new JLabel();
		scores[1]=new JLabel();
		scores[2]=new JLabel();
		scores[0].setText("����");
		scores[1].setText("�û���");
		scores[2].setText("����");
		
		
		String json = null;
		try {
			json = ClientService.getscore(user);
		} catch (RemoteException e1) {
			e1.printStackTrace();
		}
		ObjectMapper mapper = new ObjectMapper();
		JavaType javaType = mapper.getTypeFactory().constructParametricType(ArrayList.class, UserScore.class);
		try {
			rank = mapper.readValue(json, javaType);
		} catch (JsonMappingException e1) {
			e1.printStackTrace();
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
		
		
		for(Integer i=3,j=1;i<33;i=i+3,j++) {
			scores[i]=new JLabel();
			scores[i].setText(j.toString());
		}

		for(Integer i=4,j=0;i<33;i=i+3,j++) {
			scores[i]=new JLabel();
			scores[i].setText(rank.get(j).getUsername());
		}
		
		for(Integer i=5,j=0;i<33;i=i+3,j++) {
			scores[i]=new JLabel();
			scores[i].setText(""+rank.get(j).getScore());
		}
		
		for(int i=0;i<33;i++) {
			scores[i].setBounds(i%3*100+30, i/3*30+40, 70, 20);
			panel.add(scores[i]);
		}
		return panel;
	}
}
