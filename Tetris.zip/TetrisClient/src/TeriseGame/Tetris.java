package TeriseGame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.rmi.RemoteException;

import javax.swing.*;
import javax.swing.Timer;

import ClientService.ClientService;
import ClientService.UserScore;

public class Tetris extends JPanel {

	private static final long serialVersionUID = 1L;
	private int type;
	private int state;
	private int nexttype;
	private int nextstate;
	private int score = 0;
	private int[] scores_pool = { 0, 10, 20, 50, 100 };
	private int x;
	private int y;
	int width = 20;
	int height = 30;
	private int[][] map = new int[this.width + 5][this.height];
	Timer timer;
	boolean gamestate = false;
	boolean gameover = true;
	private int[] degree = { 1000, 100, 60, 30, 10 };
	private int time;
	private String level = "��";
	public String getLevel() {
		return level;
	}

	private String name ="�ο�";

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		repaint();
	}

	public void setTime(int i, String j) {
		gameover = true;
		gamestate = false;
		this.level = j;
		this.time = degree[i];
		this.timer.setDelay(this.time);
		repaint();
	}

	Font font1 = new Font("Times New Roman", Font.PLAIN, 20);
	Font font2 = new Font("����", Font.PLAIN, 11);
	Font font3 = new Font("����", Font.BOLD, 40);
	Font font4 = new Font("����", Font.BOLD, 20);

	private final int shapes[][][] = new int[][][] {
			// i
			{ { 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0 },
					{ 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0 },
					{ 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0 } },
			// s
			{ { 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0 },
					{ 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
					{ 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0 } },
			// z
			{ { 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
					{ 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
					{ 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 } },
			// j
			{ { 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0 }, { 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
					{ 1, 1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0 },
					{ 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 } },
			// o
			{ { 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
					{ 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
					{ 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 } },
			// l
			{ { 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0 }, { 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
					{ 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0 },
					{ 0, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 } },
			// t
			{ { 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, { 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0 },
					{ 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
					{ 0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0 } } };

	public void randomtype() {
		nexttype = (int) (Math.random() * 1000) % 7;
		nextstate = (int) (Math.random() * 1000) % 4;

		int t = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				map[this.width + j + 1][i + 5] = 0;
				map[this.width + j + 1][i + 5] = shapes[nexttype][nextstate][t];
				t++;
			}
		}
	}

	public void newtype() {
		type = nexttype;
		state = nextstate;
		x = (int) (this.width - 5) / 2;
		y = 0;
		if (type == 0 && (state == 0 || state == 3)) {
			x -= 1;
		}
		randomtype();
	}

	public void drawwall() {
		for (int i = 0; i < this.width - 1; i++) {
			map[i][this.height - 2] = 2;
		}
		for (int j = 0; j < this.height - 1; j++) {
			map[this.width - 2][j] = 2;
			map[0][j] = 2;
		}
	}

	public void newmap() {
		for (int i = 0; i < this.width - 1; i++) {
			for (int j = 0; j < this.height - 1; j++) {
				map[i][j] = 0;
			}
		}
		drawwall();
	}

	public void turn() {
		int tempturnState = state;
		state = (state + 1) % 4;
		if (legal(x, y, type, state) == 1) {
		}
		if (legal(x, y, type, state) == 0) {
			state = tempturnState;
		}
		repaint();
	}

	public void left() {
		if (legal(x - 1, y, type, state) == 1) {
			x = x - 1;
		}
		;
		repaint();
	}

	public void right() {
		if (legal(x + 1, y, type, state) == 1) {
			x = x + 1;
		}
		;
		repaint();
	}

	public void down() {
		if (legal(x, y + 1, type, state) == 1) {
			y = y + 1;
			delline();
		}
		if (legal(x, y + 1, type, state) == 0) {
			add(x, y, type, state);
			delline();
			newtype();
		}
		repaint();
		if (legal(x, y, type, state) == 0) {
			repaint();
			gamestate = false;
			gameover = true;
			JOptionPane.showMessageDialog(null, "GAME OVER\nscore:" + score);
			UserScore user = new UserScore();
			user.setUsername(this.name);
			user.setDegree(this.level);
			user.setScore(score);
			try {
				if(ClientService.setscore(user)) {
					System.out.println("�����ϴ��ɹ�");
				}
				else {
					System.out.println("�����ϴ�ʧ��");
				}
			} catch (RemoteException e) {
				e.printStackTrace();
			}
			score = 0;
		}
	}

	public int legal(int x, int y, int type, int state) {
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if ((shapes[type][state][i * 4 + j] == 1) && (map[x + j + 1][y + i] != 0)) {
					return 0;
				}
			}
		}
		return 1;
	}

	public void delline() {
		int line = 0;
		for (int i = 0; i < this.height - 1; i++) {
			int t = 0;
			for (int j = 0; j < this.width - 1; j++) {
				if (map[j][i] == 1) {
					t++;
				}
			}
			if (t == this.width - 3) {
				line++;
				for (int p = i; p > 0; p--) {
					for (int q = 0; q < this.width - 2; q++) {
						map[q][p] = map[q][p - 1];
					}
				}
			}
		}
		score += scores_pool[line];
	}

	public void add(int x, int y, int type, int state) {
		int t = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				if (map[x + j + 1][y + i] == 0) {
					map[x + j + 1][y + i] = shapes[type][state][t];
				}
				t++;
			}
		}
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (!gameover) {
			for (int i = 0; i < 16; i++) {
				if (shapes[type][state][i] == 1) {
					g.setColor(Color.black);
					g.fillRect((i % 4 + x + 1) * 10, (i / 4 + y) * 10, 10, 10);
				}
			}
		}
		if (gameover) {
			g.setFont(font3);
			g.drawString("�뿪ʼ����Ϸ", this.width * 10, this.height * 8);
		} else if (gamestate == false) {
			g.setFont(font3);
			g.drawString("��Ϸ��ͣ", this.width * 10, this.height * 8);
		}

		for (int j = 0; j < this.height - 1; j++) {
			for (int i = 0; i < this.width + 4; i++) {
				if (map[i][j] == 1) {
					g.setColor(Color.blue);
					g.fillRect(i * 10, j * 10, 10, 10);

				}
				if (map[i][j] == 2) {
					g.setColor(Color.black);
					g.drawRect(i * 10, j * 10, 10, 10);

				}
			}
		}
		g.setFont(font1);
		g.drawString("score=" + score, this.width * 10, 20);
		g.setFont(font2);
		g.drawString("��һ������Ϊ��", this.width * 10, 40);
		g.setFont(font4);
		g.drawString("��ӭ,"+this.name, this.width * 10, this.height*4);
		g.drawString("��ǰ�Ѷ�Ϊ��" + level, this.width * 10, this.height * 5);
	}

	public Tetris() {
		this.timer = new Timer(degree[0], new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (gamestate) {
					down();
				}
				repaint();
			}
		});
		this.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				switch (e.getKeyCode()) {
				case KeyEvent.VK_DOWN:
					down();
					break;
				case KeyEvent.VK_UP:
					turn();
					break;
				case KeyEvent.VK_RIGHT:
					right();
					break;
				case KeyEvent.VK_LEFT:
					left();
					break;
				case KeyEvent.VK_SPACE:
					gamestate = gamestate ? false : true;
					break;
				}
			}
		});
		newmap();
		repaint();
	}

	public void run() {
		newmap();
		randomtype();
		newtype();
		this.requestFocus();
		timer.start();
	}

}