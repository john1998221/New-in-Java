package ClientService;

import java.rmi.RemoteException;

import server.UserService;
import server.UserServiceProxy;

public class ClientService {
	static UserServiceProxy proxy = new UserServiceProxy();
	static UserService service = proxy.getUserService();
	public static boolean login(UserScore user) throws RemoteException {
		String json = Json.box(user);
		return service.login(json);
	}
	
	public static boolean regester(UserScore user) throws RemoteException {
		String json = Json.box(user);
		return service.regester(json);
	}
	
	public static boolean setscore(UserScore user) throws RemoteException {
		String json = Json.box(user);
		return service.setscore(json);
	}
	
	public static String getscore(UserScore user) throws RemoteException {
		String json = Json.box(user);
		return service.getscore(json);
	}
}
