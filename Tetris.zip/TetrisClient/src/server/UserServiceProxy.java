package server;

public class UserServiceProxy implements server.UserService {
  private String _endpoint = null;
  private server.UserService userService = null;
  
  public UserServiceProxy() {
    _initUserServiceProxy();
  }
  
  public UserServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initUserServiceProxy();
  }
  
  private void _initUserServiceProxy() {
    try {
      userService = (new server.UserServiceServiceLocator()).getUserService();
      if (userService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)userService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)userService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (userService != null)
      ((javax.xml.rpc.Stub)userService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public server.UserService getUserService() {
    if (userService == null)
      _initUserServiceProxy();
    return userService;
  }
  
  public boolean login(java.lang.String json) throws java.rmi.RemoteException{
    if (userService == null)
      _initUserServiceProxy();
    return userService.login(json);
  }
  
  public boolean regester(java.lang.String json) throws java.rmi.RemoteException{
    if (userService == null)
      _initUserServiceProxy();
    return userService.regester(json);
  }
  
  public boolean setscore(java.lang.String json) throws java.rmi.RemoteException{
    if (userService == null)
      _initUserServiceProxy();
    return userService.setscore(json);
  }
  
  public java.lang.String getscore(java.lang.String json) throws java.rmi.RemoteException{
    if (userService == null)
      _initUserServiceProxy();
    return userService.getscore(json);
  }
  
  
}