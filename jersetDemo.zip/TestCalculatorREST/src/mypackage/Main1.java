package mypackage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main1 {

    public static void main(String[] args) {

        System.out.println("REST��ʽ��Calculator Web Service:");

        try {

            Scanner input = new Scanner(System.in);

            System.out.println("�����������(+��-��*��/): ");
            String operator = input.next();

            System.out.println("x = ");
            double x = input.nextDouble();

            System.out.println("y = ");
            double y = input.nextDouble();

            String result = "";

            URL url = null;
            if (operator.equals("+"))
                url = new URL("http://localhost:8080/CalculatorREST/rest/CalculationService/add?x=" + x + "&y=" + y);
            if (operator.equals("-"))
                url = new URL("http://localhost:8080/CalculatorREST/rest/CalculationService/sub?x=" + x + "&y=" + y);
            if (operator.equals("*"))
                url = new URL("http://localhost:8080/CalculatorREST/rest/CalculationService/mul?x=" + x + "&y=" + y);
            if (operator.equals("/"))
                url = new URL("http://localhost:8080/CalculatorREST/rest/CalculationService/div?x=" + x + "&y=" + y);

            if (operator.equals("0"))
                url = new URL("http://localhost:8080/MavenTest2/greeting?name=555");
            
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "text/plain");
            //conn.setRequestProperty("Accept", "application/json; charset=UTF-8");

            if (conn.getResponseCode() != 200) {
            	input.close();
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }

            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

            System.out.println("Output from REST Server ......");
            while ((result = br.readLine()) != null) {
                System.out.println("������ = "+ result);
            }

            conn.disconnect();
            input.close();
        } catch (MalformedURLException e) {

            e.printStackTrace();

        } catch (IOException e) {

            e.printStackTrace();

        }
    }
}