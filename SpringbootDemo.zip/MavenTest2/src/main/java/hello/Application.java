package hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

//注解@SpringBootApplication包含许多其他注解，无需配置xml文件即可自动配置获取classpath,bean,执行main()
@SpringBootApplication
public class Application extends SpringBootServletInitializer{

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(Application.class);
    }
	
	public static void main(String[] args) {
		// SpringApplication.run(Application.class, args)该方法自动运行应用程序，无需配置web.xml或其他xml文件
		// 该应用是100%纯java应用程序，SpringBoot自动帮你解决许多配置问题
		SpringApplication.run(Application.class, args);
	}
}